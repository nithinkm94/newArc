package com.example.kaanapos.api.retrofit;

import io.reactivex.Observable;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiInterface {

//    @FormUrlEncoded
//    @POST("ajax/poslogin/poslogin")
//    Call<LoginResponse> postLoginRequest(@Field("username")String username,
//                                         @Field("password") String password,
//                                         @Field("deviceInfo") String deviceInfo);
//
//    @FormUrlEncoded
//    @POST("ajax/poslogin/getAllCompanies")
//    Observable<GetAllCompaniesResponse> postGetAllCompaniesRequest(@Field("userId") String userId,
//                                                                   @Field("name") String name);

}

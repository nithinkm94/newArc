package com.example.kaanapos.application;

import android.app.Application;

public class BaseApplication extends Application {


}

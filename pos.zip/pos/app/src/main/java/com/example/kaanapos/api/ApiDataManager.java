package com.example.kaanapos.api.retrofit;

public class ApiDataManager {
}

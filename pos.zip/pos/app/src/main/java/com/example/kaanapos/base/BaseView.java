package com.example.kaanapos.base;

public interface BaseView {
    void showToast(String message);
    void showDialogue();
    void hideDialogue();
}
